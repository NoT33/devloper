Config = {}

-- Discord Profile Picture Settings
Config.Get_Discord_PP = true  -- تغير من Get_Steam_PP إلى Get_Discord_PP
-- Discord Bot Token موجود بالفعل في server.lua

-- باقي الإعدادات تبقى كما هي
Config.Database_Location = "database.json"
Config.Server_Logo = "https://i.imgur.com/yourlogo.png"
