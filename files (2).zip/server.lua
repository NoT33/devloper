local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")

-- Discord Bot Token
local DiscordBotToken = 'MTMxNjQ3OTk2NjY3Mzg5NTQ0NA.G9Mc0c.0h3-_gMR5u3zf8z3Tp2rwZQHeOQreug4LophcI'

-- Function to get Discord ID from source
local function GetDiscordIdFromSource(source)
    for _, identifier in ipairs(GetPlayerIdentifiers(source)) do
        if string.match(identifier, "discord:") then
            return string.sub(identifier, 9)
        end
    end
    return nil
end

-- Function to create or update player data
local function CreateOrUpdatePlayerData(src, callback)
    local cid = vRP.getUserId({src})
    
    if not cid then 
        print("[Orix_AimLab] ERROR: Could not get user ID for player: " .. GetPlayerName(src))
        if callback then callback(false) end
        return 
    end

    print("[Orix_AimLab] Processing data for user ID: " .. cid .. " (Player: " .. GetPlayerName(src) .. ")")

    local file = LoadResourceFile(GetCurrentResourceName(), Config.Database_Location)
    local cfg
    
    if file and file ~= "" then
        cfg = json.decode(file)
        print("[Orix_AimLab] Loaded existing database file")
    else
        cfg = {}
        print("[Orix_AimLab] Creating new database file")
    end
    
    if not cfg then cfg = {} end

    local photo = Config.Server_Logo
    local key = tostring(cid)

    local function SavePlayerData()
        if not cfg[key] then
            cfg[key] = {
                plyname = GetPlayerName(src),
                score = 0,
                total_training = 0,
                total_target = 0,
                shooted_target = 0,
                photo = photo
            }
            print("[Orix_AimLab] ✅ Created NEW player data for: " .. GetPlayerName(src) .. " (ID: " .. cid .. ")")
        else
            cfg[key].photo = photo
            cfg[key].plyname = GetPlayerName(src)
            print("[Orix_AimLab] ✅ Updated existing player data for: " .. GetPlayerName(src) .. " (ID: " .. cid .. ")")
        end

        local jsonData = json.encode(cfg, {indent=true})
        local success = SaveResourceFile(GetCurrentResourceName(), Config.Database_Location, jsonData, -1)
        
        if success then
            print("[Orix_AimLab] ✅ Data saved successfully to: " .. Config.Database_Location)
        else
            print("[Orix_AimLab] ❌ ERROR: Failed to save data to database!")
        end
        
        if callback then callback(success) end
    end

    -- Try to get Discord profile picture
    if Config.Get_Discord_PP then
        local discordId = GetDiscordIdFromSource(src)
        if discordId then
            print("[Orix_AimLab] 🔍 Getting Discord avatar for: " .. GetPlayerName(src))
            PerformHttpRequest("https://discord.com/api/v10/users/" .. discordId, function(statusCode, response)
                if statusCode == 200 then
                    local userData = json.decode(response)
                    if userData and userData.avatar then
                        local extension = userData.avatar:sub(1,2) == "a_" and ".gif" or ".png"
                        photo = "https://cdn.discordapp.com/avatars/" .. discordId .. "/" .. userData.avatar .. extension
                        print("[Orix_AimLab] ✅ Got Discord photo for: " .. GetPlayerName(src))
                    else
                        print("[Orix_AimLab] ⚠️ No Discord avatar found for: " .. GetPlayerName(src))
                    end
                else
                    print("[Orix_AimLab] ⚠️ Discord API returned status: " .. statusCode)
                end
                SavePlayerData()
            end, "GET", "", { ["Authorization"] = "Bot " .. DiscordBotToken })
            return
        else
            print("[Orix_AimLab] ⚠️ No Discord ID found for: " .. GetPlayerName(src))
        end
    end

    SavePlayerData()
end

-- Check and Create Player Data (called by client)
RegisterServerEvent('Orix_AimLab:server:checkData')
AddEventHandler('Orix_AimLab:server:checkData', function()
    local src = source
    print("[Orix_AimLab] 📞 checkData called for: " .. GetPlayerName(src))
    CreateOrUpdatePlayerData(src, function(success)
        if success then
            TriggerClientEvent('Orix_AimLab:client:DataReady', src)
        end
    end)
end)

-- Get Player Info Function
GetPlayerInfo = function(source)
    local src = source
    local cid = vRP.getUserId({src})
    
    if not cid then 
        print("[Orix_AimLab] ❌ ERROR: Could not get user ID in GetPlayerInfo for: " .. GetPlayerName(src))
        return nil 
    end

    local file = LoadResourceFile(GetCurrentResourceName(), Config.Database_Location)
    
    if not file or file == "" then
        print("[Orix_AimLab] ❌ ERROR: Database file is empty or doesn't exist!")
        return nil
    end
    
    local cfg = json.decode(file)
    if not cfg then
        print("[Orix_AimLab] ❌ ERROR: Failed to decode database JSON!")
        return nil
    end
    
    local key = tostring(cid)
    local playerData = cfg[key] or cfg[cid]
    
    if not playerData then 
        print("[Orix_AimLab] ❌ ERROR: No data found for player ID: " .. cid)
        return nil 
    end

    print("[Orix_AimLab] ✅ Successfully retrieved data for player ID: " .. cid)
    return playerData
end

-- Get Player Info for Opening Menu
RegisterServerEvent('Orix_AimLab:server:GetPlayerInfo')
AddEventHandler('Orix_AimLab:server:GetPlayerInfo', function()
    local src = source
    print("[Orix_AimLab] 📞 GetPlayerInfo called for: " .. GetPlayerName(src))
    
    CreateOrUpdatePlayerData(src, function(success)
        if not success then
            print("[Orix_AimLab] ❌ ERROR: Failed to create/update player data")
            return
        end
        
        Wait(200)
        
        local info = GetPlayerInfo(src)
        
        if not info then 
            print("[Orix_AimLab] ❌ ERROR: Could not get player info after creation")
            return 
        end
        
        print("[Orix_AimLab] ✅ Opening menu with:")
        print("[Orix_AimLab]    Name: " .. tostring(info.plyname))
        print("[Orix_AimLab]    Photo: " .. tostring(info.photo))
        
        TriggerClientEvent('Orix_AimLab:client:OpenMenu', src, info.plyname, info.photo)
    end)
end)

-- Get Player Info for Finish Menu
RegisterServerEvent('Orix_AimLab:server:GetPlayerInfo:Finish')
AddEventHandler('Orix_AimLab:server:GetPlayerInfo:Finish', function(gamemode, difficulty)
    local src = source
    local info = GetPlayerInfo(src)
    if not info then return end
    TriggerClientEvent('Orix_AimLab:client:FinishMenu', src, info.plyname, info.photo, gamemode, difficulty)
end)

-- Finish Training
RegisterServerEvent('Orix_AimLab:server:FinishTraining')
AddEventHandler('Orix_AimLab:server:FinishTraining', function(shooted_target, total_target, score)
    local src = source
    local cid = vRP.getUserId({src})
    if not cid then return end

    local file = LoadResourceFile(GetCurrentResourceName(), Config.Database_Location)
    if not file or file == "" then return end
    
    local cfg = json.decode(file)
    if not cfg then return end
    
    local key = tostring(cid)
    local playerData = cfg[key] or cfg[cid]
    if not playerData then return end

    -- Validation
    if shooted_target < 0 or total_target < 0 or score < 0 then
        print("[Orix_AimLab] ❌ Invalid data from player: " .. GetPlayerName(src))
        return
    end

    if shooted_target > total_target then
        print("[Orix_AimLab] ❌ Shooted targets cannot be more than total targets from: " .. GetPlayerName(src))
        return
    end

    -- Update stats
    cfg[key].total_training = (cfg[key].total_training or 0) + 1
    cfg[key].shooted_target = (cfg[key].shooted_target or 0) + shooted_target
    cfg[key].total_target = (cfg[key].total_target or 0) + total_target
    cfg[key].score = (cfg[key].score or 0) + score

    SaveResourceFile(GetCurrentResourceName(), Config.Database_Location, json.encode(cfg, {indent=true}), -1)
    
    print("[Orix_AimLab] ✅ Stats updated for: " .. GetPlayerName(src))
end)

-- Fetch Leaderboard
RegisterServerEvent("Orix_AimLab:server:FetchLeaderboard")
AddEventHandler("Orix_AimLab:server:FetchLeaderboard", function()
    local src = source
    local file = LoadResourceFile(GetCurrentResourceName(), Config.Database_Location)
    local cfg = file and json.decode(file) or {}
    TriggerClientEvent("Orix_AimLab:client:GetLeaderboardData", src, cfg)
end)

-- Reset Stats Command
if Config.Reset_Stats then
    RegisterCommand(Config.Reset_Stats_Command, function(source)
        local src = source
        local cid = vRP.getUserId({src})
        if not cid then return end

        local file = LoadResourceFile(GetCurrentResourceName(), Config.Database_Location)
        if not file or file == "" then return end
        
        local cfg = json.decode(file)
        if not cfg then return end
        
        local key = tostring(cid)
        
        if cfg[key] then
            cfg[key].total_training = 0
            cfg[key].shooted_target = 0
            cfg[key].total_target = 0
            cfg[key].score = 0
            SaveResourceFile(GetCurrentResourceName(), Config.Database_Location, json.encode(cfg, {indent=true}), -1)
            TriggerClientEvent('chat:addMessage', src, {
                color = {0, 255, 0},
                multiline = true,
                args = {"AimLab", "تم إعادة تعيين إحصائياتك بنجاح!"}
            })
            print("[Orix_AimLab] ✅ Stats reset for: " .. GetPlayerName(src))
        end
    end)
end

-- Routing Bucket System
RegisterServerEvent('Orix_AimLab:server:Set-Bucket')
AddEventHandler('Orix_AimLab:server:Set-Bucket', function(bucket)
    local src = source
    if bucket == "default" then
        SetPlayerRoutingBucket(src, 0)
    elseif bucket == "random" then
        SetPlayerRoutingBucket(src, math.random(1000, 10000))
    else
        SetPlayerRoutingBucket(src, tonumber(bucket) or 0)
    end
end)
